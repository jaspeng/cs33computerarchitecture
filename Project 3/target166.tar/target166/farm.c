/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_175(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_460(unsigned x)
{
    return x + 2430129568U;
}

unsigned addval_272(unsigned x)
{
    return x + 3281031256U;
}

unsigned addval_476(unsigned x)
{
    return x + 2425393496U;
}

void setval_382(unsigned *p)
{
    *p = 3347663521U;
}

unsigned addval_202(unsigned x)
{
    return x + 2428963144U;
}

unsigned getval_474()
{
    return 3284633928U;
}

unsigned addval_349(unsigned x)
{
    return x + 3281017033U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_377()
{
    return 3353381192U;
}

void setval_134(unsigned *p)
{
    *p = 3223374477U;
}

unsigned addval_315(unsigned x)
{
    return x + 3224947353U;
}

unsigned addval_394(unsigned x)
{
    return x + 3374896777U;
}

void setval_464(unsigned *p)
{
    *p = 2579743177U;
}

void setval_192(unsigned *p)
{
    *p = 3375945353U;
}

unsigned getval_266()
{
    return 3224950425U;
}

void setval_230(unsigned *p)
{
    *p = 3383023241U;
}

unsigned getval_355()
{
    return 3532969609U;
}

unsigned addval_458(unsigned x)
{
    return x + 3767224492U;
}

unsigned addval_468(unsigned x)
{
    return x + 3234125449U;
}

unsigned addval_223(unsigned x)
{
    return x + 3286276424U;
}

unsigned getval_431()
{
    return 3676359305U;
}

unsigned addval_261(unsigned x)
{
    return x + 3674784137U;
}

unsigned getval_359()
{
    return 1019729545U;
}

unsigned addval_441(unsigned x)
{
    return x + 3223898761U;
}

unsigned addval_311(unsigned x)
{
    return x + 3252717896U;
}

unsigned addval_184(unsigned x)
{
    return x + 3768141854U;
}

unsigned addval_372(unsigned x)
{
    return x + 3767093324U;
}

unsigned addval_209(unsigned x)
{
    return x + 3353381192U;
}

unsigned addval_496(unsigned x)
{
    return x + 3676357017U;
}

void setval_376(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_448()
{
    return 3247489417U;
}

unsigned getval_152()
{
    return 3532966537U;
}

unsigned getval_110()
{
    return 3221277321U;
}

unsigned addval_350(unsigned x)
{
    return x + 2425405825U;
}

unsigned addval_327(unsigned x)
{
    return x + 3683959177U;
}

unsigned addval_473(unsigned x)
{
    return x + 3674784137U;
}

unsigned addval_446(unsigned x)
{
    return x + 3523794569U;
}

unsigned getval_485()
{
    return 3373842825U;
}

unsigned getval_125()
{
    return 3531917961U;
}

void setval_237(unsigned *p)
{
    *p = 3682126473U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
